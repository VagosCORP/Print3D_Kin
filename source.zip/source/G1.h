#ifndef G1_H
#define	G1_H

#ifdef	__cplusplus
extern "C" {
#endif


void g1_um(float xa, float ya, float xb, float yb, float dl) {
    float val_factx = (float)xb - xa;
    float val_facty = (float)yb - ya;
    float const_insqrt = (float)val_factx*val_factx + (float)val_facty*val_facty;
    float const_sqrt = (float)sqrtf(const_insqrt);
    float const_val = (float)dl / const_sqrt;
    float const_dx = (float)val_factx*const_val;
    float const_dy = (float)val_facty*const_val;
    float valx = xa;
    float valy = ya;
    long cont = 0;
    float runwhile = 1;
    float delta = 0;
    float mydelta = (float)dl*dl;
    float ang1 = 0;
    float ang2 = 0;
    float ang3 = 0;
//    putch(13);
//    send_float(xa);
//    putch(10);
//    putch(13);
//    send_float(ya);
//    putch(10);
    while(runwhile) {     
        valx = (float)valx + const_dx;
        valy = (float)valy + const_dy;
        delta = (float)(xb-valx)*(xb-valx) + (float)(yb-valy)*(yb-valy);
        if(mydelta > delta)
            runwhile = 0;
        ang1 = calc_ang1(valx/1000,valy/1000,-1800);
        ang2 = calc_ang2(valx/1000,valy/1000,-1800);
        ang3 = calc_ang3(valx/1000,valy/1000,-1800);
        cont++;
//        putch(13);
//        send_float(ang1);
//        putch(10);
//        putch(13);
//        send_float(ang2);
//        putch(10);
//        putch(13);
//        send_float(ang3);
//        putch(10);
//        putch(13);
//        send_float(valx);
//        putch(10);
//        putch(13);
//        send_float(valy);
//        putch(10);
    }
    ang1 = calc_ang1(xb/1000,yb/1000,-1800);
    ang2 = calc_ang2(xb/1000,yb/1000,-1800);
    ang3 = calc_ang3(xb/1000,yb/1000,-1800);
    cont++;
//    putch(13);
//    send_float(ang1);
//    putch(10);
//    putch(13);
//    send_float(ang2);
//    putch(10);
//    putch(13);
//    send_float(ang3);
//    putch(10);
//    putch(13);
//    send_float(xb);
//    putch(10);
//    putch(13);
//    send_float(yb);
//    putch(10);
    putch(13);
    send_float((float)cont);
    putch(10);
}

void g1(float xa, float ya, float xb, float yb, float dl) {
    g1_um(xa*1000, ya*1000, xb*1000, yb*1000, dl*1000);
}
    

#ifdef	__cplusplus
}
#endif

#endif	/* G1_H */


#ifndef COMUNIC_H
#define	COMUNIC_H

#ifdef	__cplusplus
extern "C" {
#endif

    
void putch(char val) {
    while(U1STAbits.UTXBF);
    U1TXREG = val;
}
    
void send_float(float valFloat){//funcion pensada para enviar los diferentes elementos de una variable tipo flotante de 3 bytes
    signed char i;
    for(i = 3; i >= 0; i--){
        char byte = *((unsigned char *) & valFloat + i);
        putch(byte);
    }
}

void send_int32(long valLong){
    signed char i;
    for(i = 3; i >= 0; i--){
        char byte = *((unsigned char *) & valLong + i);
        putch(byte);
    }
}

void send_int16(int valInt){////funcion pensada para enviar los diferentes elementos de una variable int (2 bytes)
    signed char i;
    for(i = 1; i >= 0; i--){
        char byte = *((unsigned char *) & valInt + i);
        putch(byte);
    }
}

float genFloat(char byte3, char byte2, char byte1, char byte0) { //a lo java!!!
    float floatRes;
    unsigned char * val3 = (unsigned char *) & floatRes + 3; //Mayor significancia
    unsigned char * val2 = (unsigned char *) & floatRes + 2; //Media mayor
    unsigned char * val1 = (unsigned char *) & floatRes + 1; //Media menor
    unsigned char * val0 = (unsigned char *) & floatRes + 0; //Menor significancia
    *val3 = byte3;
    *val2 = byte2;
    *val1 = byte1;
    *val0 = byte0;
    return floatRes;
}

long genLong(char byte3, char byte2, char byte1, char byte0) { //a lo java!!!
    long longRes;
    unsigned char * val3 = (unsigned char *) & longRes + 3; //Mayor significancia
    unsigned char * val2 = (unsigned char *) & longRes + 2; //Media mayor
    unsigned char * val1 = (unsigned char *) & longRes + 1; //Media menor
    unsigned char * val0 = (unsigned char *) & longRes + 0; //Menor significancia
    *val3 = byte3;
    *val2 = byte2;
    *val1 = byte1;
    *val0 = byte0;
    return longRes;
}

short genShort(char byte1, char byte0) { //a lo java!!!
    short shortRes;
    unsigned char * val1 = (unsigned char *) & shortRes + 1; //Media menor
    unsigned char * val0 = (unsigned char *) & shortRes + 0; //Menor significancia
    *val1 = byte1;
    *val0 = byte0;
    return shortRes;
}


#ifdef	__cplusplus
}
#endif

#endif	/* COMUNIC_H */

